<!-- HEADER -->
		<header>
			<!-- TOP HEADER -->
			<div id="top-header">

				<div class="container">
	

				</div>
			</div>
			<!-- /TOP HEADER -->

			<!-- MAIN HEADER -->
			<div id="header">
				<!-- container -->
				<div class="container">
					<!-- row -->
					<div class="row">
						<!-- LOGO -->
						<div class="col-md-2">
							<div class="header-logo">
								<a href="index.php" class="logo" >
									<img style="width: 250px; height:auto ; padding: 5px;" src="assets/logo.png" alt="Logo Comunicaciones Universo">
								</a>
							</div>
						</div>
						<!-- /LOGO -->

						<div class="col-md-9" style="text-align: right; color:#fff">
						<span >Síguenos en:</span>
							<ul class="header-payments">
								<li><a href="https://www.facebook.com/www.encap.edu.pe" target="_blank"><i class="fa fa-facebook"></i></a></li>
								<li><a href="https://www.instagram.com/encap_capacitaciones/" target="_blank"><i class="fa fa-instagram"></i></a></li>
								<li><a href="https://wa.link/gq6z5w" target="_blank"><i class="fa fa-whatsapp"></i></a></li>
								<li><a href="https://www.linkedin.com/company/encap-capacitaciones" target="_blank"><i class="fa fa-telegram"></i></a></li>
								<li><a href="https://www.youtube.com/c/ENCAPCAPACITACIONES" target="_blank"><i class="fa fa-youtube"></i></a></li>
							</ul>
							 
						</div>
						<div class="col-md-1" style="display: flex;flex-wrap: nowrap;align-content: center;justify-content: center;align-items: center;height: 70px;">
						    <a href="https://sistemas.encap.edu.pe/bolsa_de_trabajo/admin/vistas/login.html" style="color:white" target="_blank">
						        <i class="fa fa-user-circle-o" style="color:white" aria-hidden="true"></i> Admin</a> 
						</div>
					</div>
					<!-- row -->
				</div>
				<!-- container -->
			</div>
			<!-- /MAIN HEADER -->
		</header>
		<!-- /HEADER -->


