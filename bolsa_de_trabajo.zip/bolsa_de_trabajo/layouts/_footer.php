		<!-- FOOTER -->
		<footer id="footer">
			<!-- top footer -->
			<div class="section">
				<!-- container -->
				<div class="container" >
					<!-- row -->
					<div class="row" >
						<div class="col-md-4 col-xs-6">
							<div class="footer">
										
							<div class="header-logo">
								<a href="index.php" class="logo" >
									<img style="width: 320px; height:auto ; padding: 5px;" src="assets/logo.png" alt="Logo Comunicaciones Universo">
								</a>
							</div><br>						

								<p>Encap es una organización privada con presencia a nivel nacional e internacional, dedicada a brindar servicios de capacitación y especialización a diferentes profesionales, técnicos y administrativos vinculados con el ámbito público y privado.</p>
								<ul class="footer-links">
									<li><a href="#"><i class="fa fa-phone"></i>Cel. 951 428 884 - Área Comercial</a></li>
									<li><a href="#"><i class="fa fa-phone"></i>Cel. 954 791 924 - Área Legal</a></li>
									<li><a href="www.encap.edu.pe" style="color: #fff;"><i class="fa fa-internet-explorer"></i>www.encap.edu.pe</a></li>
								</ul>
							</div>
						</div>

						<div class="col-md-4 col-xs-6">
							<div class="footer">
							<h3 class="footer-title"></h3>
								<div class="row">
									<div class="col-md-6">
									<ul class="footer-links">
										<li><a href="https://encap.edu.pe/cursos/courses/?status%5B%5D=hot&search=&is_lms_filter=1" target="_blank"><i class="fa fa-caret-right"></i>Cursos</a></li>
										<li><a href="https://encap.edu.pe/cursos/courses/?status%5B%5D=hot&search=&is_lms_filter=1" target="_blank"><i class="fa fa-caret-right"></i>Diplomas</a></li>				 
										<li><a href="https://encap.edu.pe/cursos/courses/?status%5B%5D=hot&search=&is_lms_filter=1" target="_blank"><i class="fa fa-caret-right"></i>Diplomas de Especializacion</a></li>
										<li><a href="https://www.facebook.com/www.encap.edu.pe" target="_blank"><i class="fa fa-caret-right"></i>Cursos en Vivo</a></li>
										<li><a href="https://walink.co/cc9281" target="_blank"><i class="fa fa-caret-right"></i>Cursos In House </a></li>

									</ul>
									</div>
									<div class="col-md-6">
									<ul class="footer-links">
										<li><a href="index.php" target="_blank"><i class="fa fa-caret-right"></i>Inicio</a></li>
										<li><a href="https://encap.edu.pe/cursos/sobre-nosotros" target="_blank"><i class="fa fa-caret-right"></i>Sobre Nosotros</a></li>				 
										<li><a href="https://encap.edu.pe/cursos/trabaja-con-nosotros" target="_blank"><i class="fa fa-caret-right"></i>Conviértete en Instructor</a></li>
										<li><a href="https://aula.encap.edu.pe" target="_blank"><i class="fa fa-caret-right"></i>Aula Virtual</a></li>
										<li><a href="https://sistemas.encap.edu.pe/certificados" target="_blank"><i class="fa fa-caret-right"></i>Validación de Certificados</a></li>
										<li><a href="https://sistemas.encap.edu.pe/tracking" target="_blank"><i class="fa fa-caret-right"></i>Seguimiento de Certificados</a></li>

									</ul>
									</div>
								</div>
							</div>
						</div>
						<div class="clearfix visible-xs"></div> 
						<div class="col-md-4 col-xs-6">
							<div class="footer">
								<h3 class="footer-title">Horario de Atención</h3>
								<ul class="footer-links">
									<li><a href="#"><i class="fa fa-clock-o"></i>Lunes a viernes de 8 a.m a 10 p.m </a></li>
									<li><a href="#"><i class="fa fa-calendar"></i> Sábados, domingos y feriados <br> 9 a.m a 6 p.m </a></li>
									<li><a href="https://wa.link/gq6z5w" target="_blank" style="font-size: 38px;"><i class="fa fa-whatsapp"></i><strong style="font-size: 30px;"> 951 428 884 </strong></a></li>
									<li><a href="https://wa.link/ydsi3k" target="_blank" style="font-size: 38px;"><i class="fa fa-whatsapp"></i><strong style="font-size: 30px;" > 930 627 791 </strong></a></li>
								</ul>
							</div>
						</div>
					</div>
					<!-- /row -->
				</div>
				<!-- /container -->
			</div>
			<!-- /top footer -->

			<!-- bottom footer -->
			<div id="bottom-footer" class="section">
				<div class="container">
					<!-- row -->
					<div class="row">
						<div class="col-md-12 text-center">
							<!-- <ul class="footer-payments">
								<li><a href="#"><i class="fa fa-facebook"></i></a></li>
								<li><a href="#"><i class="fa fa-instagram"></i></a></li>
								<li><a href="#"><i class="fa fa-whatsapp"></i></a></li>
								<li><a href="#"><i class="fa fa-telegram"></i></a></li>
							</ul> -->
							<span class="copyright"> 					
								Copyright &copy;<script>document.write(new Date().getFullYear());</script> Desarrollado  <i class="fa fa-heart-o" aria-hidden="true"></i>  por <a href="https://www.facebook.com/www.encap.edu.pe" target="_blank">ENCAP S.A.C.</a>
		
							</span>
						</div>
					</div>
						<!-- /row -->
				</div>
				<!-- /container -->
			</div>
			<!-- /bottom footer -->
		</footer>
		<!-- /FOOTER -->