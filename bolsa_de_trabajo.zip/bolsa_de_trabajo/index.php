<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width,initial-scale=1.0">
	<title>Convocatoria ENCAP </title>
	<!-- Google font -->
	<link href="https://fonts.googleapis.com/css?family=Montserrat:400,500,700" rel="stylesheet">

	<!-- Bootstrap -->
	<link type="text/css" rel="stylesheet" href="css/bootstrap.min.css"/>

	<!-- Slick -->
	<link type="text/css" rel="stylesheet" href="css/slick.css"/>
	<link type="text/css" rel="stylesheet" href="css/slick-theme.css"/>

	<!-- nouislider -->
	<link type="text/css" rel="stylesheet" href="css/nouislider.min.css"/>

	<!-- Font Awesome Icon -->
	<link rel="stylesheet" href="font-awesome-4.7.0/css/font-awesome.min.css">
		
	<!-- Custom stlyles  -->
	<link rel="stylesheet" type="text/css" href="css/index.css">

	<!-- Slick -->
	<link type="text/css" rel="stylesheet" href="css/slick.css"/>
	<link type="text/css" rel="stylesheet" href="css/slick-theme.css"/>
	
	<!-- Favicon -->
	<link rel="icon" href="../files/ENCAP.ico">
	
	<script type="text/javascript" src="js/jquery-3.4.1.min.js"></script>
</head>

<body>
<!-- cabezera de la pagina  -->
<?php include("layouts/_main-header.php"); ?>
<?php include('servicios/_conexion.php'); ?>
<!-- Custom stlyles  -->
	<!-- HOT DEAL SECTION -->
	<div id="hot-deal" class="section">
		<!-- container -->
		<div class="container">
			<!-- row -->
			<div class="row">
				<div class="col-md-12">
					<div class="hot-deal">
	
					</div>
				</div>
			</div>
			<!-- /row -->
		</div>
		<!-- /container -->
	</div>
	<!-- /HOT DEAL SECTION -->

	<!-- SECTION Smartphones-->
	<div class="section">
		<!-- container -->
		<div class="container">
			<!-- row -->
			<div class="row">
				<!-- SEARCH BAR -->
				<div class="col-md-12 col-sm-12 col-xs-12">
					<h5 style="padding:10px">Total de empleos registrados ( <?php $articuloss=mysqli_query($con,"SELECT IFNULL(count(idempleo),0) as idempleo FROM empleos WHERE condicion=1;"); 
							$resultadoo = mysqli_fetch_assoc($articuloss); echo $resultadoo["idempleo"]; ?> )</h5> 
					<div class="clock" >								
						<p class="icon-datos"> <span  id="Date"> </span> &nbsp; <i class="fa fa-calendar"></i> </p>
						<ul>
							<li id="hours"></li>
							<li id="point">:</li>
							<li id="min"></li>
							<li id="point">:</li>
							<li id="sec"></li> &nbsp;
							<i class="fa fa-clock-o"></i> 
						</ul>
					</div>
				</div> 

				<div class="col-md-2 col-sm-1 col-xs-1">
				</div> 

				<div class="col-md-8 col-sm-10 col-xs-10">
					<div class="header-search" class="col-md-8 col-sm-12 col-xs-12">
						<div class="formbus" class="col-md-8 col-sm-12 col-xs-12">	
							<h4 style="padding: 5px;">Encuentra tu próximo empleo</h4>											
							<input class="input" type="text" id="idbusqueda" placeholder="Coloca el perfil que estás buscando..." value="<?php if(isset($_GET['text'])){echo $_GET['text'];}else{echo '';} ?>">
							<button class="search-btn" onclick="search_producto()" aria-hidden="true">Buscar</button>
							
								<select class="form-control select-picker" name="provincia" id="provincia" style="margin-top: 10px;" >
								
								    <option value="AMAZONAS">AMAZONAS</option>
									<option value="ÁNCASH">ÁNCASH</option>
									<option value="APURÍMAC">APURÍMAC</option>
									<option value="AREQUIPA">AREQUIPA</option>
									<option value="AYACUCHO">AYACUCHO</option>
									<option value="CAJAMARCA">CAJAMARCA</option>
									<option value="CALLAO">CALLAO</option>
									<option value="CUSCO">CUSCO</option>
									<option value="HUANCAVELICA">HUANCAVELICA</option>
									<option value="HUÁNUCO">HUÁNUCO</option>
									<option value="ICA">ICA</option>
									<option value="JUNÍN" >JUNÍN</option>
									<option value="LA LIBERTAD">LA LIBERTAD</option>
									<option value="LAMBAYEQUE">LAMBAYEQUE</option>
									<option value="LIMA" selected>LIMA</option>
									<option value="LORETO">LORETO</option>
									<option value="MADRE DE DIOS">MADRE DE DIOS</option>
									<option value="MOQUEGUA">MOQUEGUA</option>
									<option value="PASCO">PASCO</option>
									<option value="PIURA">PIURA</option>
									<option value="PUNO">PUNO</option>
									<option value="SAN MARTÍN">SAN MARTÍN</option>
									<option value="TACNA">TACNA</option>
									<option value="TUMBES">TUMBES</option>
									<option value="UCAYALI">UCAYALI</option>
								</select>
													
						</div>								
					</div>
				</div>

				<div class="col-md-2 col-sm-1 col-xs-1">
				</div>
				<!-- /SEARCH BAR -->
			</div>

			<div class="row">
				<div class="main-content">
					<div class="content-page">		
						<!-- section empleo -->
						<div class="col-md-12 col-sm-12 col-xs-12">					
						<?php 
						if(!empty($_REQUEST["nume"])){ $_REQUEST["nume"] = $_REQUEST["nume"];}else{ $_REQUEST["nume"] = '1';}
						if($_REQUEST["nume"] == "" ){$_REQUEST["nume"] = "1";}
						$articulos=mysqli_query($con,"SELECT * FROM empleos where condicion=1 AND fechafin>=CURDATE();");
						$num_registros=@mysqli_num_rows($articulos);
						$registros= '4';
						$pagina=$_REQUEST["nume"];
						if (is_numeric($pagina))
						$inicio= (($pagina-1)*$registros);
						else
						$inicio=0;
						$busqueda=mysqli_query($con,"SELECT idempleo, nombre, empresa, ubicacion,nvacantes,renumeracion, destacado, detalle, replace(nombre,' ','_') as nombree,
						CONCAT(DAY( fechainicio),'/', MONTH(fechainicio),'/', YEAR(fechainicio))as fechainicio, CONCAT(DAY( fechafin),'/', MONTH(fechafin),'/', YEAR(fechafin))as fechafin 
						FROM empleos where condicion=1 AND fechafin>=CURDATE() ORDER BY idempleo DESC LIMIT $inicio,$registros ");
						$paginas=ceil($num_registros/$registros);						
						?> 
						<?php while ($resultado = mysqli_fetch_assoc($busqueda)){ ?>						
								<div class="product">
									<div class="row">
										<h3 class="product-name"><a  href="producto.php?p=<?php echo $resultado["idempleo"] ?>"> <?php echo utf8_encode($resultado["nombre"]); ?></h3>
										<h5>ENTIDAD: <strong  class="entidad"><?php echo utf8_encode($resultado["empresa"]); ?></strong></h5></a><br>
										<div class="col-md-2 col-xs-12">
											<div class="product-img">
												<a href="producto.php?p=<?php echo $resultado["idempleo"]; ?>">												
												<img src="assets/encap.png"><br>
												<strong style="padding: 10px;"><?php if ($resultado["destacado"]==1) echo '<span class="badge" style="background: red;"><i class="fa fa-star"></i> Vigente</span>' ; ?></strong><br>	
												</a>	
											</div>
										</div>

										<div class="col-md-7 col-xs-12">
											<div class="product-body">
												<p class="icon-datos"><a><i class="fa fa-map-marker"></i></a> Ubicación: <span class="datos"> <?php echo utf8_encode($resultado["ubicacion"]); ?> </span> </p>
												<p class="icon-datos"><a><i class="fa fa-users"></i></a> Cantidad de Vacantes: <span class="datos"> <?php echo $resultado["nvacantes"]; ?> </span> </p>
												<p class="icon-datos"><a><i class="fa fa-usd"></i></a> Remuneración: <span class="datos"> S/ <?php echo $resultado["renumeracion"]; ?> </span> </p>
												<p class="icon-datos"><a><i class="fa fa-calendar"></i></a> Fecha Inicio de Publicación: <span class="datos"><?php  echo $resultado["fechainicio"]; ?> </span> </p>
												<p class="icon-datos"><a><i class="fa fa-calendar-times-o"></i></a> Fecha Fin de Publicación: <span class="datos"> <?php echo $resultado["fechafin"]; ?> </span> </p>
											</div>
										</div>

										<div class="col-md-3 col-xs-12">			
											<div class="add-to-cart">
												<button class="add-to-cart-btn"><a  href="producto.php?p=<?php echo $resultado["idempleo"]; ?>"><i class="fa fa-eye"></i> Ver más</a></button>
											</div>
										</div>
									</div>
								</div>						
						<?php } ?>
						</div>
					</div>
				</div>
			</div>
		

				<!-- paginacion //////////////////////////////////////-->
				<div class="col-md-12" style="text-align: center;">
					<ul class="pagination">
						<li>
						<?php
						if($_REQUEST["nume"] == "1" ){
						$_REQUEST["nume"] == "0";
						echo  "";
						}else{
						if ($pagina>1)
							$ant = $_REQUEST["nume"] - 1;
							echo "<a class='page-link' aria-label='Previous' href='index.php?nume=1'><span aria-hidden='true'>&laquo;</span><span class='sr-only'>Previous</span></a>"; 
							echo "<li class='page-item '><a class='page-link' href='index.php?nume=". ($pagina-1) ."' >".$ant."</a></li>"; }
							echo "<li class='page-item active'><a class='page-link' >".$_REQUEST["nume"]."</a></li>"; 
							$sigui = $_REQUEST["nume"] + 1;
							$ultima = $num_registros / $registros;
						if ($ultima == $_REQUEST["nume"] +1 ){
							$ultima == "";}
						if ($pagina<$paginas && $paginas>1)
							echo "<li class='page-item'><a class='page-link' href='index.php?nume=". ($pagina+1) ."'>".$sigui."</a></li>"; 
						if ($pagina<$paginas && $paginas>1)
							echo "
							<li class='page-item'><a class='page-link' aria-label='Next' href='index.php?nume=". ceil($ultima) ."'><span aria-hidden='true'>&raquo;</span><span class='sr-only'>Next</span></a>
							</li>";
						?>
					</ul>
				</div>
				<!-- end paginacion ///////////////////////// -->
			</div>
			<!-- /row -->
		</div>
		<!-- /container -->
	</div>
	<!-- /SECTION -->
	
	<!-- NEWSLETTER -->
	<div id="newsletter" class="section">
		<!-- container -->
		<div class="container">
			<!-- row -->
			<div class="row">
				<div class="col-md-12">
					<div class="newsletter">
						<p>Entérate de más <strong>Curso, Diplomas y Diplomas de Especialización</strong></p>

						<ul class="newsletter-follow">
							<li>
								<a href="https://www.facebook.com/www.encap.edu.pe" target="_blank"><i class="fa fa-facebook"></i></a>
							</li>
							<li>
								<a href="https://wa.link/gq6z5w" target="_blank"><i class="fa fa-whatsapp"></i></a>
							</li>
							<li>
								<a href="https://www.instagram.com/encap_capacitaciones/" target="_blank"><i class="fa fa-instagram"></i></a>
							</li>	
							<li>
								<a href="https://www.youtube.com/c/ENCAPCAPACITACIONES" target="_blank"><i class="fa fa-youtube"></i></a>
							</li>								
						</ul>
					</div>
				</div>
			</div>
			<!-- /row -->
		</div>
		<!-- /container -->
	</div>
	<!-- /NEWSLETTER -->

	<!-- Pie de pagina de la web  -->
	<?php include("layouts/_footer.php"); ?>

		<!-- jQuery Plugins -->
		<script src="js/jquery.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<script src="js/slick.min.js"></script>
		<script src="js/nouislider.min.js"></script>
		<script src="js/jquery.zoom.min.js"></script>
		<script src="js/main.js"></script>
		<script type="text/javascript" src="js/main-scripts.js"></script>

		<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.6.2/jquery.min.js"></script>
		<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.6.2/jquery.min.js"></script>
		<script type="text/javascript">
		$(document).ready(function() {
		// Making 2 variable month and day
		var monthNames = [ "Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Setiembre", "Octubre", "Noviembre", "Deciembre" ]; 
		var dayNames= ["Domingo","Lunes","Martes","Miercoles","Jueves","Viernes","Sabado"]

		// make single object
		var newDate = new Date();
		// make current time
		newDate.setDate(newDate.getDate());
		// setting date and time
		$('#Date').html(dayNames[newDate.getDay()] + " " + newDate.getDate() + ' de ' + monthNames[newDate.getMonth()] + ' del ' + newDate.getFullYear());

		setInterval( function() {
		// Create a newDate() object and extract the seconds of the current time on the visitor's
		var seconds = new Date().getSeconds();
		// Add a leading zero to seconds value
		$("#sec").html(( seconds < 10 ? "0" : "" ) + seconds);
		},1000);

		setInterval( function() {
		// Create a newDate() object and extract the minutes of the current time on the visitor's
		var minutes = new Date().getMinutes();
		// Add a leading zero to the minutes value
		$("#min").html(( minutes < 10 ? "0" : "" ) + minutes);
		},1000);

		setInterval( function() {
		// Create a newDate() object and extract the hours of the current time on the visitor's
		var hours = new Date().getHours();
		// Add a leading zero to the hours value
		$("#hours").html(( hours < 10 ? "0" : "" ) + hours);
		}, 1000); 
		});
</script>

</body>
</html>


