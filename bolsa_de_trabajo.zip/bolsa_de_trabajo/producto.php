<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width,initial-scale=1.0">
	<title>Convocatoria ENCAP</title>
	<!-- Google font -->
	<link href="https://fonts.googleapis.com/css?family=Montserrat:400,500,700" rel="stylesheet">

	<!-- Bootstrap -->
	<link type="text/css" rel="stylesheet" href="css/bootstrap.min.css"/>

	<!-- Slick -->
	<link type="text/css" rel="stylesheet" href="css/slick.css"/>
	<link type="text/css" rel="stylesheet" href="css/slick-theme.css"/>

	<!-- nouislider -->
	<link type="text/css" rel="stylesheet" href="css/nouislider.min.css"/>

	<!-- Font Awesome Icon -->
	<link rel="stylesheet" href="font-awesome-4.7.0/css/font-awesome.min.css">
		
	<!-- Custom stlyles  -->
	<link rel="stylesheet" type="text/css" href="css/index.css">

	<!-- Slick -->
	<link type="text/css" rel="stylesheet" href="css/slick.css"/>
	<link type="text/css" rel="stylesheet" href="css/slick-theme.css"/>

	<link rel="canonical" href="https://getbootstrap.com/docs/5.0/examples/carousel/">

	<!-- Favicon -->
	<link rel="icon" href="../files/ENCAP.ico">
	
	<script type="text/javascript" src="js/jquery-3.4.1.min.js"></script>
</head>

<body>
	<!-- cabezera d ela pagina  -->
	<?php include("layouts/_main-header.php"); ?>
	<?php include('servicios/_conexion.php'); ?>
	<!-- Custom stlyles  -->

		<!-- BREADCRUMB -->
		<div id="breadcrumb" class="section">
			<!-- container -->
			<div class="container">
				<!-- row -->
				<div class="row">
					<div class="col-md-12">
						<ul class="breadcrumb-tree">
							<li><a href="index.php">Inicio</a></li>
							<li class="active" ><a href="#" id="idmarca">Empleos</a></li>							
						</ul>
					</div>
				</div>
				<!-- /row -->
			</div>
			<!-- /container -->
		</div>
		<!-- /BREADCRUMB -->

			<!-- SEARCH BAR -->
				<div class="row">
					<div class="col-md-2 col-sm-1 col-xs-1">
					</div> 

					<div class="col-md-8 col-sm-10 col-xs-10">
						<div class="header-search" class="col-md-8 col-sm-12 col-xs-12">
						    <div class="clock" >
						    	<ul>
						    	     <li class="icon-datos"><i class="fa fa-calendar"></i> <span  id="Date"> </span></li>&nbsp;&nbsp;
						    	   &nbsp;
								 	<i class="fa fa-clock-o"></i> &nbsp;
									<li id="hours"></li>
									<li id="point">:</li>
									<li id="min"></li>
									<li id="point">:</li>
									<li id="sec"></li>
								</ul>
							</div>
							
							<div class="formbus" class="col-md-8 col-sm-12 col-xs-12">															
								<input class="input" type="text" id="idbusqueda" placeholder="Coloca el perfil que estás buscando..." value="<?php if(isset($_GET['text'])){echo $_GET['text'];}else{echo '';} ?>">
								<button class="search-btn" onclick="search_producto()" aria-hidden="true">Buscar</button>	
								<br>
							<div style="text-align: left; padding: 15px;">
								<a href="index.php"><button class="regresar-btn"><i class="fa fa-reply"></i> Regresar a la lista de empleos</button></a>
							</div>			
						</div>
					</div>

					<div class="col-md-2 col-sm-1 col-xs-1">
					</div>
				</div>

			<!-- /SEARCH BAR -->
					
	<!-- SECTION Smartphones-->
		<div class="section">
			<!-- container -->
			<div class="container">
				<!-- row -->
				<div class="row">
					<!-- section title -->
					<div class="col-md-12 ">
						<div class="col-md-4 col-sm-4 col-xs-12">
						    <a href="https://wa.link/8wjf79" target="_blank">
							   
								<img style="padding:5px" id="img-publi-iz" class="img-publi-iz" src="assets/INTERNO111.jpg">		
							</a>
							<a href="https://wa.link/xdatsp" target="_blank">
							   
								<img style="padding:5px" id="img-publi-iz" class="img-publi-iz" src="assets/INTERNO22.jpg">		
							</a>	
						</div>

						<div class="col-md-8 col-sm-8 col-xs-12">
							<div >
								<h3 class="product-name" style="padding:0px 0px 10px 0px;"><i class="fa fa-id-card-o"></i> Aviso: </h3>
								<div style="text-align: center;padding:10px;background-color: #fff; box-shadow: 1px 2px 2px 3px #E4E7ED, 0px 0px 0px 1px #E4E7ED; border-radius: 3px 3px 3px 3px;">
									<h3 id="idtitle" style="color: #034bb8;">Empleo </h3>
									<h5 id="idempresa" >Empleo </h5>
								</div>
								
							</div>
							<br>			
							
							<h3  class="product-name"><i class="fa fa-male"></i> Sobre el aviso: </h3>
							<div class="product-details" style="padding: 10px;">								
								<div style="padding: 10px;background-color: #fff; box-shadow: 1px 2px 2px 3px #E4E7ED, 0px 0px 0px 1px #E4E7ED; border-radius: 3px 3px 3px 3px;">
									<h4 >Requerimiento:</h4>
									<ul class="tab-nav" style="padding: 0px 0px 0px 15px">
										<li style="padding: 5px 0px ;" ><i class="fa fa-caret-right"></i><a data-toggle="tab" href="#tab1"> EXPERIENCIA: </a><span id="idexperiencia"> </span> </li>
										<li style="padding: 5px 0px ;"><i class="fa fa-caret-right"></i><a data-toggle="tab" href="#tab1"> FORMACIÓN ACADÉMICA - PERFIL: </a><span id="idformacion"> </span> </li>
										<li style="padding: 5px 0px ;"><i class="fa fa-caret-right"></i><a data-toggle="tab" href="#tab1"> ESPECIALIZACIÓN: </a><span id="idespecializacion"> </span> </li>
										<li style="padding: 5px 0px ;"><i class="fa fa-caret-right"></i><a data-toggle="tab" href="#tab1"> CONOCIMIENTO: </a><span id="idconocimiento"> </span> </li>
										<li style="padding: 5px 0px ;"><i class="fa fa-caret-right"></i><a data-toggle="tab" href="#tab1"> COMPETENCIAS: </a><span id="idcompetencia"> </span> </li>
									</ul>
									<br>
									<h4 >Detalle:</h4>
									<?php 								
								 	$idempleos =  $_GET["p"];

									$busqueda=mysqli_query($con,"SELECT detalle	FROM empleos where idempleo='$idempleos' AND condicion=1");
									$regc=$busqueda->fetch_object();
									$detalleV=$regc->detalle;									
									?>
									<div style="padding: 10px 50px;">
									<button style="background-color: rgb(20, 75, 160);
    color: rgb(232, 230, 227);border-radius: 10px;padding:5px;padding-left:10px;padding-right:10px;color:white;border:0"><a href="<?php echo $detalleV; ?>" target="_blanck" style="color:white" >Ir al Enlace de convocatoria</a></button>										
									</div>
									<div class="caja-det">
									<span class="product-available"> Ubicación:  <span style="color: #272627; font-weight: 400; font-size:14px;padding:0px 10px;" id="idubicacion"> </span></span><br>
									<span class="product-available"> Cantidad de Vacantes:  <span style="color: #272627; font-weight: 400; font-size:14px;padding:0px 10px; " id="idnvacantes"> </span></span><br>
									<span class="product-available"> Remuneración: S/ <span style="color: #272627; font-weight: 400; font-size:14px; padding:0px 3px;" id="idrenumeracion"></span></span><br>
									<span class="product-available"> Fecha Inicio de Publicación:  <span style="color: #272627; font-weight: 400; font-size:14px; padding:0px 10px;" id="idfechainicio"> </span></span><br>
									<span class="product-available"> Fecha Fin de Publicación:  <span style="color: #272627; font-weight: 400; font-size:14px; padding:0px 10px;" id="idfechafin"> </span></span><br>
									</div>
								</div>
							</div>
							<!-- <div class="col-md-12" style="padding:0px 0px;">
								<a href="">
									<img class="img-publi-debajo" src="assets/banner-debajo.jpg">		
								</a>
							</div> -->
						</div>
					</div>	
				</div>
					<!-- /section title -->		

				</div>
				</div>
				</div>
			<!-- /row -->
			</div>
			<!-- /container -->
		</div>
		<!-- /SECTION -->

	<?php include("layouts/_footer.php"); ?>

		<!-- jQuery Plugins -->
		<script src="js/jquery.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<script src="js/slick.min.js"></script>
		<script src="js/nouislider.min.js"></script>
		<script src="js/jquery.zoom.min.js"></script>
		<script src="js/main.js"></script>
	<script type="text/javascript" src="js/main-scripts.js"></script>

	<script type="text/javascript">
		var p='<?php echo $_GET["p"]; ?>';
		console.log(p);
	</script>
	<script type="text/javascript">
		$(document).ready(function(){
			$.ajax({
				url:'servicios/empleos/get_all_products.php',
				type:'POST',
				data:{},
				success:function(data){
					console.log(data);
					let html='';
					for (var i = 0; i < data.datos.length; i++) {
						if (data.datos[i].codpro==p) {
							//document.getElementById("idempleoos").innerHTML=data.datos[i].idempleo;
							document.getElementById("idtitle").innerHTML=data.datos[i].nompro;
							document.getElementById("idempresa").innerHTML=data.datos[i].empresa;
							document.getElementById("idexperiencia").innerHTML=data.datos[i].experiencia;
							document.getElementById("idformacion").innerHTML=data.datos[i].formacion;
							document.getElementById("idespecializacion").innerHTML=data.datos[i].especializacion;
							document.getElementById("idconocimiento").innerHTML=data.datos[i].conocimiento;
							document.getElementById("idcompetencia").innerHTML=data.datos[i].competencia;
							
							document.getElementsByName("iddetalle").innerHTML=data.datos[i].detalle;
							//document.getElementById("iddetalle").innerHTML=data.datos[i].detalle;
							document.getElementById("idubicacion").innerHTML=data.datos[i].ubicacion;
							document.getElementById("idnvacantes").innerHTML=data.datos[i].nvacantes;
							document.getElementById("idrenumeracion").innerHTML=data.datos[i].renumeracion;
							document.getElementById("idfechainicio").innerHTML=data.datos[i].fechainicio;
							document.getElementById("idfechafin").innerHTML=data.datos[i].fechafin;	
							$("#idempleoos").val(data.datos[i].idempleo);										

						}
	
					}

				},
				error:function(err){
					console.error(err);
				}
			});
		});
		</script>	
</body>
</html>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.6.2/jquery.min.js"></script>
		<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.6.2/jquery.min.js"></script>
		<script type="text/javascript">
		$(document).ready(function() {
		// Making 2 variable month and day
		var monthNames = [ "Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Setiembre", "Octubre", "Noviembre", "Deciembre" ]; 
		var dayNames= ["Domingo","Lunes","Martes","Miercoles","Jueves","Viernes","Sabado"]

		// make single object
		var newDate = new Date();
		// make current time
		newDate.setDate(newDate.getDate());
		// setting date and time
		$('#Date').html(dayNames[newDate.getDay()] + " " + newDate.getDate() + ' de ' + monthNames[newDate.getMonth()] + ' del ' + newDate.getFullYear());

		setInterval( function() {
		// Create a newDate() object and extract the seconds of the current time on the visitor's
		var seconds = new Date().getSeconds();
		// Add a leading zero to seconds value
		$("#sec").html(( seconds < 10 ? "0" : "" ) + seconds);
		},1000);

		setInterval( function() {
		// Create a newDate() object and extract the minutes of the current time on the visitor's
		var minutes = new Date().getMinutes();
		// Add a leading zero to the minutes value
		$("#min").html(( minutes < 10 ? "0" : "" ) + minutes);
		},1000);

		setInterval( function() {
		// Create a newDate() object and extract the hours of the current time on the visitor's
		var hours = new Date().getHours();
		// Add a leading zero to the hours value
		$("#hours").html(( hours < 10 ? "0" : "" ) + hours);
		}, 1000); 
		});
</script>