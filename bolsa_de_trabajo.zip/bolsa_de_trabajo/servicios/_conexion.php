<?php
	$con=mysqli_connect('localhost','encapedu_bolsa_de_trabajo','BDT=bdt22@encap$','encapedu_bolsa_de_trabajo');
	/*
	$con=mysqli_connect(
	'ubicacion de la BD',
	'usuario de la base de datos',
	'contraseña del usuario de la base de datos',

	*/
?>