<?php
ob_start();
session_start();
//si la ariable de sesion no existe
if (!isset($_SESSION["idpersonal"]))
{
  header("Location: login.html");
}
else
{
require 'modulos/header.php';
//Usuario revisa el contenido
if ($_SESSION['personal']==1)
{
?>

<!--Contenido-->
<div class="content-wrapper">    
        <!-- Main content -->
      <section class="content">
      <section class="content-header">
            <br>
            <ol class="breadcrumb">      
              <li><a href="inicio.php"><i class="fa fa-dashboard"></i> Inicio</a></li>      
              <li class="active">Administrar usuarios</li>    
            </ol>
        </section>
        <div class="panel panel-default" style="border-color: #666; border-width: 3px; border-style: double;">
          <div class="panel-heading">
            <div class="box-header with-border" >
                <h1 class="box-title">Administrar usuarios</h1>
      
            </div>
          </div>

          <div class="panel-body table-responsive" class="box-body" id="listadoregistros">
            <button class="btn btn-primary" data-toggle="modal" data-target="#myModal" style="font-size:18px"><i class="fa fa-plus"> Crear Nuevo Usuario </i>
            </button>
            <br><br>
            <table id="tbllistado" class="table table-striped table-bordered table-condensed table-hover" width="100%">
                  <thead>
                    <th>Nombre Empleado</th>
                    <th>Usuario</th>
                    <th>Estado</th>
                    <th>Acciones</th>
                  </thead>
                  <tbody>                            
                  </tbody>
                  <tfoot>
                    <th>Nombre Empleado</th>
                    <th>Usuario</th>
                    <th>Estado</th>
                    <th>Acciones</th>
                  </tfoot>
            </table>
          </div>
        </div>
      </section>

          <div class="panel-body table-responsive" class="box-body" id="listadoregistros">
            <table id="tbllistadousuarios" class="table table-striped table-bordered table-condensed table-hover" width="100%">
                  <thead>
                    <th>Nombre Empleado</th>
                    <th>Permisos</th>
                  </thead>
                  <tbody>                            
                  </tbody>
                  <tfoot>
                    <th>Nombre Empleado</th>
                    <th>Permisos</th>
                  </tfoot>
            </table>
          </div>
        
</div>

<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
      <!-- form -->
      <form class="form-horizontal" role="form" name="formulario" id="formulario" method="POST">

        <div class="modal-header" style="background:#151e38; color:white">
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
          <h4 class="modal-title text-center"> Formulario de Usuarios</h4>
        </div>

        <div class="modal-body">
          <div class="form-group">
            <label for="name" class="col-sm-3 control-label">Personal:</label>
            <div class="col-sm-6">
              <input type="hidden" name="idusuario" id="idusuario">
              <select id="idpersonal" name="idpersonal" class="form-control selectpicker" data-live-search="true" required></select>
            </div>
          </div>

          <div class="form-group">
            <label for="name" class="col-sm-3 control-label">Usuario<spam style="color: #c0392b ; font-size: 18px">*</spam>: </label>
            <div class="col-sm-6"> 
              <input type="text" class="form-control" name="login" id="login" maxlength="20" placeholder="Usuario" required>
            </div>
          </div>

          <div class="form-group">
            <label for="name" class="col-sm-3 control-label">Clave<spam style="color: #c0392b ; font-size: 18px">*</spam>:</label>
            <div class="col-sm-6">
              <input type="password" class="form-control" name="clave" id="clave" maxlength="64" placeholder="Clave" required>
            </div>
          </div>

           <div class="form-group">
            <label for="name" class="col-sm-3 control-label">Permisos:</label>
            <div class="col-sm-6">
              <ul style="list-style: none;" id="permisos">
                              
              </ul>
            </div>
          </div>

        </div>
          <div class="text-center" style="color: #c0392b "><p><spam style="color: #c0392b ; font-size: 18px">*</spam> Campos obligatorios</p>
          </div>
                    
        <div class="modal-footer">
          <button type="button" onclick="cancelarform()" class="btn btn-danger pull-left" data-dismiss="modal"><i class="fa fa-times"></i> Cerrar</button>
          <button class="btn btn-primary" type="submit" id="btnGuardar"><i class="fa fa-save"></i> Guardar</button>
        </div>
      </form>        
    </div>
  </div>
</div> 

<!-- Fin modal -->


<?php
}
else
{
  require 'notieneacceso.php';
}
require 'modulos/footer.php';
?>
<script type="text/javascript" src="js/usuario.js"></script>

<?php 
}
ob_end_flush();
?>