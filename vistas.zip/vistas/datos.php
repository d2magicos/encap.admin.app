<?php 
//servidor base de datos
define("DB_HOST", "localhost");

//nombre de la base de datos
define("DB_NAME", "encapedu_bdencapsistema");


//nombre de usuario de base de datos
define("DB_USERNAME", "encapedu_sistemasencap");

//conraseña del usuario de base de datos
define("DB_PASSWORD", "KU(O(6J&CDDWencap2022");

//codificacion de caracteres
define("DB_ENCODE", "utf8");

//nombre del proyecto
define("PRO_NOMBRE", "SISTEMA ENCAP");
 
 ?>