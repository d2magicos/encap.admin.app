<?php

$host = "localhost";
$usuario= "encapedu_sistemasencap";
$contraseña = "KU(O(6J&CDDWencap2022";

try {
   $conexion = new PDO("mysql:host=$host;dbname=encapedu_bdencapsistema", $usuario, $contraseña);
   $conexion->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
   $conexion->exec("set names utf8");
    return$conexion;
    }
catch(PDOException $error)
    {
    echo "No se pudo conectar a la BD: " . $error->getMessage();
    }

?>
