<?php
//Activamos el almacenamiento en el buffer
ob_start();
session_start();

if (!isset($_SESSION["nombre"]))
{
  header("Location: login.html");
}
else
{
require 'modulos/header.php';

if ($_SESSION['envios']==1)
{
?>
<!--Contenido-->
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <section class="content-header">
    <br>
    <ol class="breadcrumb">      
      <li><a href="inicio.php"><i class="fa fa-dashboard"></i> Inicio</a></li>      
      <li class="active">Administrar Envios</li>    
    </ol>
  </section>

  <section class="content">
    <div class="panel panel-default" style="border-color: #666; border-width: 3px; border-style: double;">
      <div class="panel-heading">
        <div class="box-header with-border">
            <h1 class="box-title">Lista de Envios Realizados</h1>
            <div class="box-tools pull-right">
              <button class="btn btn-box-tool" data-widget="collapse">
                <i class="fa fa-minus"></i>
              </button>
              <button class="btn btn-box-tool" data-widget="remove">
                <i class="fa fa-times"></i>
              </button>
            </div>
        </div>
      </div>

   <!-- /.col -->
      
   <div class="panel-body table-responsive" class="box-body" id="listadoregistros">
        <table id="tbllistado" class="table table-striped table-bordered table-condensed table-hover" width="100%">
              <thead>
                <th>N°</th>
                <th>Fecha Matricula</th>
                <th style="color:red">Fecha de envio</th>   
                <th>Código Matricula</th>
                <th>DNI</th>
                <th>Participante</th>
                <th>Telefono</th>
                <th>Telefono 2</th>
                <th>Correo</th>          
                <th>Curso</th>
                <th>Tipo </th>
                <th>Fecha Curso</th>   
                <th>Ciudad</th>               
                <th style="color:red">Lugar enviado</th>
                <th style="color:red">Monto</th>
                <th style="color:red">Courier</th>
                <th style="color:red">Factura</th> 
                <th style="color:red">Clave</th>                
                            
                <th style="color:red">Fecha de envio de información</th>
                <th>Estado</th>
                <th>Acciones</th>
                <th>Observaciones</th>                
                <th style="color:green">Dirección de envío</th>
                <th style="color:green">Observaciones para el cliente</th>
              </thead>
              <tbody>                            
              </tbody>
              <tfoot>
                <th>N°</th>
                <th>Fecha Matricula</th>
                <th style="color:red">Fecha de envio</th>   
                <th>Código Matricula</th>
                <th>DNI</th>
                <th>Participante</th>
                <th>Telefono</th>
                <th>Telefono 2</th>
                <th>Correo</th>          
                <th>Curso</th>
                <th>Tipo </th>
                <th>Fecha Curso</th>  
                <th>Ciudad</th>                
                <th style="color:red">Lugar enviado</th>
                <th style="color:red">Monto</th>
                <th style="color:red">Courier</th>
                <th style="color:red">Factura</th> 
                <th style="color:red">Clave</th>                
                            
                <th style="color:red">Fecha de envio de información</th>
                <th>Estado</th>
                <th>Acciones</th>
                <th>Observaciones</th>
                <th style="color:green">Dirección de envío</th>
                <th style="color:green">Observaciones para el cliente</th>
              </tfoot>
        </table>
      </div><!-- /.col -->
    </div><!-- /.row -->
  </section><!-- /.content -->
</div><!-- /.content-wrapper -->
<!--Fin-Contenido-->
 
  <!-- Modal -->
<form id="formulario" class="modal fade" method="POST">
  <div class="modal-dialog modal-lg" style="width: 1500px">
            <!-- Modal content-->
        <div class="modal-content panel panel-primary"> 

              <div class="modal-header panel-heading" style="background-color: #01324b">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                  <h4 class="modal-title text-center"><span >FORMULARIO </span> VISTA DE ENVIO REALIZADO</h4>  
              </div>

              <div class="modal-body panel-body">                       
                  <div class="form-group col-lg-3">
                    <label class="col-form-label">Personal (*)</label>
                    <input type="hidden" name="idpersonal" id="idpersonal">  
                      <input type="text" class="form-control" name="nombrepersonal" id="nombrepersonal" readonly>
                  </div>

                  <div class="form-group col-lg-4 col-md-4 col-sm-4 col-xs-12">
                     <label>Fecha (*):</label>
                      <div class="input-group date">
                        <div class="input-group-addon">
                          <i class="fa fa-calendar"></i> </div>
                        <input class="form-control pull-right" type="text" name="fecha_horam" id="fecha_horam" readonly>
                      </div>
                  </div>

                  <div class="form-group col-lg-4 col-md-8 col-sm-8 col-xs-12">
                    <label>Codigo de matricula (*):</label>
                    <div class="input-group">
                      <span class="input-group-addon"><i class="fa fa-bookmark-o"></i></span>
                      <input type="hidden" name="idenvio" id="idenvio">                  
                      <input type="hidden" name="idmatricula" id="idmatricula">    
                      <input type="text" class="form-control" name="cod_matriculam" id="cod_matriculam" style="color:red; width: 500px; height:34px" maxlength="100" readonly >                        
                    </div>
                  </div>
              </div>

               
              <div class="modal-header panel-heading" style="background-color: #01324b">
                  <h4 class="modal-title" ><span id="titulo-formulario">Datos</span> del participante</h4>  
              </div>

              <div class="form-group col-lg-12 col-md-3 col-sm-6 col-xs-12" style="background-color: #fff"><br>
                
                <div class="form-group col-lg-2 col-md-4 col-sm-4 col-xs-12">
                  <label>Tipo de documento (*):</label>
                  <div class="input-group" >                    
                    <span class="input-group-addon" ><i class="fa fa-file-text-o"></i></span> 
                    <select style="height:34px" class="form-control select-picker" name="tipo_documentom" id="tipo_documentom" >
                        <option value="DNI"selected="selected">DNI</option>
                        <option value="RUC">RUC</option>
                        <option value="CE">CE - Carnet de extranjeria</option>
                        <option value="PAS">PAS - Pasaporte</option>
                      </select>
                  </div>
                </div>

                <div class="form-group col-lg-2 col-md-4 col-sm-4 col-xs-12">              
                  <label>Número de documento (*):</label> 
                  <div class="input-group" >   
                  <span class="input-group-addon"><i class="fa fa-instagram"></i></span> 
                    <input style=" height:34px" type="text" class="form-control" name="num_documentom" id="num_documentom"   readonly>
                 </div>
                </div>

                <div class="form-group col-lg-4 col-md-8 col-sm-8 col-xs-12">
                  <label>Nombre del participante (*):</label>
                  <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-users"></i></span>                 
                    <input style=" height:34px" type="text" class="form-control" id="nombrem" name="nombrem" readonly >                 
                  </div>
                </div>
            
                <div class="form-group col-lg-2 col-md-8 col-sm-8 col-xs-12">
                  <label>Teléfono 1 (*):</label>
                  <div class="input-group" >      
                    <span class="input-group-addon" ><i class="fa fa-mobile"></i></span> 
                    <input type="text" class="form-control"  type="text" name="telefonom" id="telefonom" maxlength="20" readonly >
                  </div>
                </div>

                <div class="form-group col-lg-2 col-md-8 col-sm-8 col-xs-12">
                  <label>Teléfono 2 (*):</label>
                  <div class="input-group" >      
                    <span class="input-group-addon" ><i class="fa fa-mobile"></i></span> 
                    <input type="text" class="form-control"  type="text" name="telefono2m" id="telefono2m" maxlength="20" readonly  >
                  </div>
                </div>
              
                <div class="form-group col-lg-2 col-md-4 col-sm-4 col-xs-12">
                  <label>Email (*):</label>
                  <div class="input-group date">
                    <div class="input-group-addon">
                      <i class="fa fa-envelope-o fa-fw"></i>
                    </div>
                    <input class="form-control"   type="email" name="emailm" id="emailm" maxlength="80" readonly>
                  </div>
                </div>

                <div class="form-group col-lg-2 col-md-8 col-sm-8 col-xs-12">
                  <label>País (*):</label>
                  <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-map fa-fw"></i></span>   
                    <input type="text" class="form-control" name="paism" id="paism" maxlength="20" readonly>           
                  </div>
                </div>

                <div class="form-group col-lg-2 col-md-8 col-sm-8 col-xs-12">
                  <label>Departamento (*):</label>
                  <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-map fa-fw"></i></span>   
                    <input type="text" class="form-control" name="departamentom" id="departamentom" maxlength="50" readonly>           
                  </div>
                </div>

                <div class="form-group col-lg-2 col-md-8 col-sm-8 col-xs-12">
                  <label>Ciudad (*):</label>
                  <div class="input-group" >      
                    <span class="input-group-addon" ><i class="fa fa-map fa-fw"></i></span> 
                    <input type="text" class="form-control" name="ciudadm" id="ciudadm"  maxlength="70" readonly>
                  </div>
                </div>           

                <div class="form-group col-lg-2 col-md-8 col-sm-8 col-xs-12">
                  <label>Dirección (*):</label>
                  <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-map fa-fw"></i></span>   
                    <input type="text" class="form-control" name="direccionm" id="direccionm" maxlength="300" readonly>           
                  </div>
                </div>

                <div class="form-group col-lg-2 col-md-8 col-sm-8 col-xs-12">
                  <label>Fecha de cumpleaños (*):</label>
                  <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-calendar"></i></span>   
                    <input type="text" class="form-control" name="fecha_cumplem" id="fecha_cumplem" maxlength="20" readonly>           
                  </div>
                </div>                 
              </div>
              
            <div class="modal-header panel-heading" style="background-color: #01324b">                
                  <h4 class="modal-title" ><span id="titulo-formulario">Datos</span> del curso</h4>  
            </div>         
             
            <div class="form-group col-lg-12 col-md-3 col-sm-6 col-xs-12" style="border: 1px solid #d1f2eb; background:  #fff"><br>
                <div class="form-group col-lg-12 col-md-12 col-xs-12">
                  <table id="detallesm" class="table table-striped table-bordered table-condensed table-hover"width="100%">
                      <tbody>
         
                      </tbody>
                      </table>
                </div>
            </div>
          

            <div class="modal-header panel-heading" style="background-color: #e74c3c ">
                <h4 class="modal-title" style="color:#fff"><span id="titulo-formulario">Detalles</span> del envío para el cliente</h4>  
            </div>

            <div class="form-group col-sm-6 col-lg-12 " style="background: #fff ; padding:5px 10px" >
              <div class="row">
                <div class="form-group col-lg-2 col-md-8 col-sm-8 col-xs-12">
                  <label>Lugar de confirmación:</label>
                  <div class="input-group" >    
                    <select class=" form-control select-picker"  style="width:200px; height:35px" name="lugarenvio" id="lugarenvio" required >
                    <option value="Abancay">1 Abancay</option>
                      <option value="Acobamba">2 Acobamba</option>
                      <option value="Acomayo">3 Acomayo</option>
                      <option value="Aija">4 Aija</option>
                      <option value="Alto Amazonas">5 Alto Amazonas</option>
                      <option value="Ambo">6 Ambo</option>
                      <option value="Andahuaylas">7 Andahuaylas</option>
                      <option value="Angaraes">8 Angaraes</option>
                      <option value="Anta">9 Anta</option>
                      <option value="Antabamba">10 Antabamba</option>
                      <option value="Antonio Raimondi">11 Antonio Raimondi</option>
                      <option value="Arequipa">12 Arequipa</option>
                      <option value="Ascope">13 Ascope</option>
                      <option value="Asunción">14 Asunción</option>
                      <option value="Atalaya">15 Atalaya</option>
                      <option value="Ayabaca">16 Ayabaca</option>
                      <option value="Aymaraes">17 Aymaraes</option>
                      <option value="Azángaro">18 Azángaro</option>
                      <option value="Bagua">19 Bagua</option>
                      <option value="Barranca">20 Barranca</option>
                      <option value="Bellavista">21 Bellavista</option>
                      <option value="Bolívar">22 Bolívar</option>
                      <option value="Bolognesi">23 Bolognesi</option>
                      <option value="Bongara">24 Bongara</option>
                      <option value="Cajabamba">25 Cajabamba</option>
                      <option value="Cajamarca">26 Cajamarca</option>
                      <option value="Cajatambo">27 Cajatambo</option>
                      <option value="Calca">28 Calca</option>
                      <option value="Camaná">29 Camaná</option>
                      <option value="Canas">30 Canas</option>
                      <option value="Canchis">31 Canchis</option>
                      <option value="Candarave">32 Candarave</option>
                      <option value="Cangallo">33 Cangallo</option>
                      <option value="Canta">34 Canta</option>
                      <option value="Cañete">35 Cañete</option>
                      <option value="Carabaya">36 Carabaya</option>
                      <option value="Caravelí">37 Caravelí</option>
                      <option value="Carhuaz">38 Carhuaz</option>
                      <option value="Carlos Fermín Fitzcarrald">39 Carlos Fermín Fitzcarrald</option>
                      <option value="Casma">40 Casma</option>
                      <option value="Castilla">41 Castilla</option>
                      <option value="Castrovirreyna">42 Castrovirreyna</option>
                      <option value="Caylloma">43 Caylloma</option>
                      <option value="Celendín">44 Celendín</option>
                      <option value="Chachapoyas">45 Chachapoyas</option>
                      <option value="Chanchamayo">46 Chanchamayo</option>
                      <option value="Chepén">47 Chepén</option>
                      <option value="Chiclayo">48 Chiclayo</option>
                      <option value="Chincha">49 Chincha</option>
                      <option value="Chincheros">50 Chincheros</option>
                      <option value="Chota">51 Chota</option>
                      <option value="Chucuito">52 Chucuito</option>
                      <option value="Chumbivilcas">53 Chumbivilcas</option>
                      <option value="Chupaca">54 Chupaca</option>
                      <option value="Churcampa">55 Churcampa</option>
                      <option value="Concepción">56 Concepción</option>
                      <option value="Condesuyos">57 Condesuyos</option>
                      <option value="Condorcanqui">58 Condorcanqui</option>
                      <option value="Contralmirante Villar">59 Contralmirante Villar</option>
                      <option value="Contumazá">60 Contumazá</option>
                      <option value="Coronel Portillo">61 Coronel Portillo</option>
                      <option value="Corongo">62 Corongo</option>
                      <option value="Cotabambas">63 Cotabambas</option>
                      <option value="Cutervo">64 Cutervo</option>
                      <option value="Cuzco">65 Cuzco</option>
                      <option value="Daniel Alcides  Carrión">66 Daniel Alcides Carrión</option>
                      <option value="Datem del Marañón">67 Datem del Marañón</option>
                      <option value="Dos de Mayo">68 Dos del Mayo</option>
                      <option value="El Collao">69 El Collao</option>
                      <option value="El Dorado">70 El Dorado</option>
                      <option value="Espinar">71 Espinar</option>
                      <option value="Ferreñafe">72 Ferreñafe</option>
                      <option value="General Sánchez Cerro">73 General Sánchez Cerro</option>
                      <option value="Gran Chimú">74 Gran Chimú</option>
                      <option value="Grau">75 Grau</option>
                      <option value="Huacaybamba">76 Huacaybamba</option>
                      <option value="Hualgayoc">77 Hualgayoc</option>
                      <option value="Huallaga">78 Huallaga</option>
                      <option value="Huamalíes">79 Huamalíes</option>
                      <option value="Huamanga">80 Huamanga</option>
                      <option value="Huanca Sancos">81 Huanca Sancos</option>
                      <option value="Huancabamba">82 Huancabamba</option>
                      <option value="Huancané">83 Huancané</option>
                      <option value="Huancavelica">84 Huancavelica</option>
                      <option value="Huancayo">85 Huancayo</option>
                      <option value="Huanta">86 Huanta</option>
                      <option value="Huánuco">87 Huánuco</option>
                      <option value="Huaral">88 Huaral</option>
                      <option value="Huaraz">89 Huaraz</option>
                      <option value="Huari">90 Huari</option>
                      <option value="Huarmey">91 Huarmey</option>
                      <option value="Huarochirí">92 Huarochirí</option>
                      <option value="Huaura">93 Huaura</option>
                      <option value="Huaylas">94 Huaylas</option>
                      <option value="Huaytará">95 Huaytará</option>
                      <option value="Ica">96 Ica</option>
                      <option value="Ilo">97 Ilo</option>
                      <option value="Islay">98 Islay</option>
                      <option value="Jaén">99 Jaén</option>
                      <option value="Jauja">100 Jauja</option>
                      <option value="Jorge Basadre">101 Jorge Basadre</option>
                      <option value="Julcán">102 Julcán</option>
                      <option value="Junín">103 Junín</option>
                      <option value="La Convención">104 La Convención</option>
                      <option value="La Mar">105 La Mar</option>
                      <option value="La Unión">106 La Unión</option>
                      <option value="Lamas">107 Lamas</option>
                      <option value="Lambayeque">108 Lambayeque</option>
                      <option value="Lampa">109 Lampa</option>
                      <option value="Lauricocha">110 Lauricocha</option>
                      <option value="LeoncioPrado">111 LeoncioPrado</option>
                      <option value="Lima">112 Lima</option>
                      <option value="Loreto">113 Loreto</option>
                      <option value="Lucanas">114 Lucanas</option>
                      <option value="Luya">115 Luya</option>
                      <option value="Manu">116 Manu</option>
                      <option value="Marañón">117 Marañón</option>
                      <option value="Mariscal Cáceres">118 Mariscal Cáceres</option>
                      <option value="Mariscal Luzuriaga">119 Mariscal Luzuriaga</option>
                      <option value="Mariscal Nieto">120 Mariscal Nieto</option>
                      <option value="Mariscal RamónCastilla">121 Mariscal Ramón Castilla</option>
                      <option value="Maynas">122 Maynas</option>
                      <option value="Melgar">123 Melgar</option>
                      <option value="Moho">124 Moho</option>
                      <option value="Morropón">125 Morropón</option>
                      <option value="Moyobamba">126 Moyobamba</option>
                      <option value="Nazca">127 Nazca</option>
                      <option value="Ocros">128 Ocros</option>
                      <option value="Otuzco">129 Otuzco</option>
                      <option value="Oxapampa">130 Oxapampa</option>
                      <option value="Oyón">131 Oyón</option>
                      <option value="Pacasmayo">132 Pacasmayo</option>
                      <option value="Pachitea">133 Pachitea</option>
                      <option value="Padre Abad">134 Padre Abad</option>
                      <option value="Paita">135 Paita</option>
                      <option value="Pallasca">136 Pallasca</option>
                      <option value="Palpa">137 Palpa</option>
                      <option value="Parinacochas">138 Parinacochas</option>
                      <option value="Paruro">139 Paruro</option>
                      <option value="Pasco">140 Pasco</option>
                      <option value="Pataz">141 Pataz</option>
                      <option value="Páucar del Sara Sara">142 Páucar del Sara Sara</option>
                      <option value="Paucartambo">143 Paucartambo</option>
                      <option value="Picota">144 Picota</option>
                      <option value="Pisco">145 Pisco</option>
                      <option value="Piura">146 Piura</option>
                      <option value="Pomabamba">147 Pomabamba</option>
                      <option value="Prov. Const. del Callao">148 Prov. Const. del Callao</option>
                      <option value="PuertoInca">149 PuertoInca</option>
                      <option value="Puno">150 Puno</option>
                      <option value="Purús">151 Purús</option>
                      <option value="Putumayo">152 Putumayo</option>
                      <option value="Quispicanchi">153 Quispicanchi</option>
                      <option value="Recuay">154 Recuay</option>
                      <option value="Requena">155 Requena</option>
                      <option value="Rioja">156 Rioja</option>
                      <option value="Rodríguez de Mendoza">157 Rodríguez de Mendoza</option>
                      <option value="San Antonio de Putina">158 San Antonio de Putina</option>
                      <option value="San Ignacio">159 San Ignacio</option>
                      <option value="San Marcos">160 San Marcos</option>
                      <option value="San Martín">161 San Martín</option>
                      <option value="San Miguel">162 San Miguel</option>
                      <option value="San Pablo">163 San Pablo</option>
                      <option value="San Román">164 San Román</option>
                      <option value="Sánchez Carrión">165 Sánchez Carrión</option>
                      <option value="Sandia">166 Sandia</option>
                      <option value="Santa">167 Santa</option>
                      <option value="Santa Cruz">168 Santa Cruz</option>
                      <option value="Santiago de Chuco">169 Santiago de Chuco</option>
                      <option value="Satipo">170 Satipo</option>
                      <option value="Sechura">171 Sechura</option>
                      <option value="Sihuas">172 Sihuas</option>
                      <option value="Sucre">173 Sucre</option>
                      <option value="Sullana">174 Sullana</option>
                      <option value="Tacna">175 Tacna</option>
                      <option value="Tahuamanu">176 Tahuamanu</option>
                      <option value="Talara">177 Talara</option>
                      <option value="Tambopata">178 Tambopata</option>
                      <option value="Tarata">179 Tarata</option>
                      <option value="Tarma">180 Tarma</option>
                      <option value="Tayacaja">181 Tayacaja</option>
                      <option value="Tocache">182 Tocache</option>
                      <option value="Trujillo">183 Trujillo</option>
                      <option value="Tumbes">184 Tumbes</option>
                      <option value="Ucayali">185 Ucayali</option>
                      <option value="Urubamba">186 Urubamba</option>
                      <option value="Utcubamba">187 Utcubamba</option>
                      <option value="Víctor Fajardo">188 Víctor Fajardo</option>
                      <option value="Vilcashuamán">189 Vilcashuamán</option>
                      <option value="Virú">190 Virú</option>
                      <option value="Yarowilca">191 Yarowilca</option>
                      <option value="Yauli">192 Yauli</option>
                      <option value="Yauyos">193 Yauyos</option>
                      <option value="Yungay">194 Yungay</option>
                      <option value="Yunguyo">195 Yunguyo</option>
                      <option value="Zarumilla">196 Zarumilla</option>
                      </select>                     
                  </div>
                </div>

                <div class="form-group col-lg-2 col-md-8 col-sm-8 col-xs-12">
                  <label>Monto:</label>
                  <div class="input-group"> 
                    <input type="text" class="form-control" name="monto" id="monto" maxlength="10" style="width:200px; height:35px" placeholder="Ingrese el monto de Envio: 8.50"  >           
                  </div>
                  <label for="name" class="control-label text-right" style="color: #c0392b ; font-size: 14px">* Obligatorio</label>
                </div>           

                <div class="form-group col-lg-2 col-md-8 col-sm-8 col-xs-12">
                  <label>Courier:</label>
                  <div class="input-group">    
                    <select id="idcourier" name="idcourier" class="selectpicker" data-live-search="true" style="width: 320px; height:34px;" ></select>              
                  </div>
                  <label for="name" class="control-label text-right" style="color: #c0392b ; font-size: 14px">* Obligatorio</label>
                </div>

                <div class="form-group col-lg-6 col-md-8 col-sm-8 col-xs-12">
                  <label>Dirección de envío:</label>
                  <div class="input-group">    
                    <input type="text" class="form-control" name="direccion_envio" id="direccion_envio" style="width:700px;" maxlength="500" placeholder="Dirección de envío de courier y número de courier" >                     
                  </div>                  
                </div>
              </div>

              <div class="row">
                <div class="form-group col-lg-2 col-md-8 col-sm-8 col-xs-12">
                  <label>Fecha de envío:</label>
                  <div class="input-group">
                    <input type="date" class="form-control" name="fechaenvio" id="fechaenvio" style="width:200px; height:35px" maxlength="200" placeholder="Fecha de envio" >           
                  </div>
                  <label for="name" class="control-label text-right" style="color: #c0392b ; font-size: 14px">* Obligatorio</label>
                </div> 

                <div class="form-group col-lg-2 col-md-8 col-sm-8 col-xs-12">
                  <label>Clave de envío:</label>
                  <div class="input-group">
                    <input type="text" class="form-control" name="clave" id="clave" style="width:200px; height:35px" maxlength="200" placeholder="Clave de envio" >           
                  </div>
                  <label for="name" class="control-label text-right" style="color: #c0392b ; font-size: 14px">* Obligatorio</label>
                </div> 

                <div class="form-group col-lg-2 col-md-8 col-sm-8 col-xs-12">
                  <label>Número de factura de envío:</label>
                  <div class="input-group">
                    <input type="text" class="form-control" name="factura_envio" id="factura_envio" style="width:220px; height:35px" maxlength="200" placeholder="Factura de envio" >           
                  </div>
                  <label for="name" class="control-label text-right" style="color: #c0392b ; font-size: 14px">* Obligatorio</label>
                </div>
                <div class="form-group col-lg-6 col-md-8 col-sm-8 col-xs-12">
                  <label>Observaciones para el Cliente:</label>
                  <div class="input-group">    
                    <input type="text" class="form-control" name="observacion_cliente" id="observacion_cliente" style="width:700px;"  maxlength="500" placeholder="Observaciones para el cliente de su envío" >                     
                  </div>                  
                </div>
              </div>

              <div class="row" >              

                <div class="form-group col-lg-12 col-md-8 col-sm-8 col-xs-12" style=" border-color: #666; border-width: 2px 0px 0px 0px; border-style: dashed;"><br>
                  <label>Observaciones de envío interno:</label>
                  <div class="input-group">
                    <textarea style="width: 1400px; height:40px" type="text" class="form-control" name="observaciones" id="observaciones" placeholder="Observaciones" maxlength="200" > </textarea>          
                  </div>
                </div> 
              </div>
            </div>   
              
            <div class="modal-footer panel-footer">
                 <button class="btn btn-primary" type="submit" id="btnGuardar" style="font-size:18px" ><i class="fa fa-save"></i> Guardar y Actualizar Envio</button>
                  <button type="button" class="btn btn-danger pull-left" data-dismiss="modal" style="font-size:18px" ><i class="fa fa-times"></i> Cancelar</button>
            </div>          
        </div>        
  </div>
</form>
<?php
}
else
{
  require 'notieneacceso.php';
}

require 'modulos/footer.php';
?>
<script type="text/javascript" src="js/listadeenvios.js"></script>
<?php 
}
ob_end_flush();
?>



